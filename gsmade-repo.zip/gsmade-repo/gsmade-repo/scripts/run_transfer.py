#!/usr/bin/env python3
"""Generalization / transfer protocols (feeds Table 7b): in-family,
leave-one-workflow-out (LOWO, i.e. leave-one-family-out among the
synthetic families), cross-scale, and zero-shot (synthetic -> real
WfCommons trace families).

What's actually being measured: the GAT policy (gsmade/gat_policy.py) is
a 2-layer graph-attention network with no instance-size-dependent
parameters, so nothing stops it from being *run* on a workflow it never
trained on -- the question each protocol below asks is whether doing so
still produces a *useful* seed population, not whether it's possible.
For every held-out test instance and evaluation seed we run full GS-MADE
twice with everything else identical:
  - "transferred_policy": seeding_fraction=beta, using a policy trained
    only on the protocol's train split (never the test instance/family/
    scale/domain);
  - "no_policy": seeding_fraction=0, i.e. GS-MADE's search machinery
    (L-SHADE + VNS) with no learned seeding at all.
The hypervolume/IGD gap between the two rows for the same (instance,
seed) is the transfer signal: a positive gap means the out-of-
distribution policy is still helping; a gap near zero or negative means
it isn't, which is a legitimate (and reportable) outcome of running this
code, not a bug.

Protocols:
  in-family    train on all-but-one instance of a family, test on the
               held-out instance (leave-one-instance-out within family).
  lowo         train on every synthetic family except one, test on the
               held-out family's instances.
  cross-scale  train on one task-count scale of a family, test on a
               different scale of the *same* family.
  zero-shot    train on every synthetic instance found, test on whatever
               real WfCommons trace instances exist locally (there are
               none by default -- see data/instances/README.md; the
               protocol is skipped with a message if none are present).

Same honesty note as the other scripts/run_*.py: real, runnable code,
small smoke defaults, --full for the paper's protocol scale, and numbers
produced are not expected to reproduce Table 7b's published values.
"""
from __future__ import annotations

import argparse
import glob
import os
import sys
import time
from collections import defaultdict

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import pandas as pd

from _common import ROOT, load_environment, load_seeds, pretrain_policy_multi  # noqa: E402

from gsmade import metrics
from gsmade.encoding import chromosome_length
from gsmade.environment import Environment
from gsmade.gat_policy import GATPolicy
from gsmade.lshade import LSHADEConfig
from gsmade.scheduler import GSMADE, GSMADEConfig
from gsmade.workflow import REAL_TRACE_FAMILIES, SYNTHETIC_FAMILIES, Workflow


def load_instances(instances_glob: str) -> dict[str, dict[int, list[tuple[str, Workflow]]]]:
    """family -> scale -> [(path, Workflow), ...]"""
    by_family: dict[str, dict[int, list[tuple[str, Workflow]]]] = defaultdict(lambda: defaultdict(list))
    for path in sorted(glob.glob(instances_glob)):
        wf = Workflow.load(path)
        by_family[wf.family][wf.num_tasks].append((path, wf))
    return by_family


def _score_against(train_workflows: list[Workflow], test_workflow: Workflow,
                    environment: Environment, train_seeds: list[int], eval_seeds: list[int],
                    pop_size: int, max_evals: int, policy_episodes: int, beta: float,
                    vns_mu: int, protocol: str, train_scope: str) -> list[dict]:
    if not train_workflows:
        print(f"  [skip] {protocol}: no training workflows available for {test_workflow.name}")
        return []
    policy = pretrain_policy_multi(train_workflows, environment, train_seeds, policy_episodes, hidden_dim=16)

    rows = []
    for seed in eval_seeds:
        variants: dict[str, tuple[list[tuple], dict]] = {}
        for variant, seeding_fraction in (("transferred_policy", beta), ("no_policy", 0.0)):
            cfg = GSMADEConfig(
                lshade=LSHADEConfig(dim=chromosome_length(test_workflow), pop_size_init=pop_size,
                                     pop_size_min=max(6, pop_size // 5), max_evals=max_evals),
                seeding_fraction=seeding_fraction, elite_fraction=0.2, vns_period=vns_mu,
            )
            use_policy = policy if seeding_fraction > 0 else None
            t0 = time.time()
            gsm = GSMADE(test_workflow, environment, cfg, use_policy, np.random.default_rng(seed))
            result = gsm.run()
            variants[variant] = (result["front"], {"evals_used": result["evals_used"], "wall_s": time.time() - t0})

        pooled = [p for front, _ in variants.values() for p in front]
        if not pooled:
            continue
        ref = metrics.reference_point(pooled, percentile=95.0)
        ref_set = metrics.build_igd_reference_set(pooled)

        for variant, (front, meta) in variants.items():
            hv = metrics.hypervolume(front, ref) if front else 0.0
            ig = metrics.igd(front, ref_set) if front else float("inf")
            best = min(front, key=lambda p: p[0]) if front else (float("nan"),) * 3
            rows.append({
                "protocol": protocol, "train_scope": train_scope,
                "test_instance": test_workflow.name, "family": test_workflow.family,
                "scale": test_workflow.num_tasks, "seed": seed, "variant": variant,
                "makespan_s": best[0], "energy_j": best[1], "cost_usd": best[2],
                "hypervolume": hv, "igd": ig, "front_size": len(front),
                **meta,
            })
    return rows


def run_in_family(by_family, environment, train_seeds, eval_seeds, pop_size, max_evals,
                   policy_episodes, beta, vns_mu, max_test_per_family: int) -> list[dict]:
    rows = []
    for family, by_scale in by_family.items():
        all_instances = [wf for insts in by_scale.values() for _, wf in insts]
        if len(all_instances) < 2:
            print(f"  [skip] in-family/{family}: need >=2 instances, found {len(all_instances)}")
            continue
        # smallest-scale instances first, so --max-test-per-family actually
        # keeps a smoke run fast (unlike a bare instance-discovery order,
        # see scripts/_common.py's smallest_first docstring for why)
        all_instances = sorted(all_instances, key=lambda wf: wf.num_tasks)
        for test_wf in all_instances[:max_test_per_family]:
            train_wfs = [wf for wf in all_instances if wf.name != test_wf.name]
            rows += _score_against(train_wfs, test_wf, environment, train_seeds, eval_seeds,
                                    pop_size, max_evals, policy_episodes, beta, vns_mu,
                                    "in-family", f"{family} minus {test_wf.name}")
    return rows


def run_lowo(by_family, environment, train_seeds, eval_seeds, pop_size, max_evals,
             policy_episodes, beta, vns_mu, max_test_per_family: int) -> list[dict]:
    rows = []
    synthetic_present = [f for f in by_family if f in SYNTHETIC_FAMILIES]
    if len(synthetic_present) < 2:
        print(f"  [skip] lowo: need >=2 synthetic families, found {synthetic_present}")
        return rows
    for held_out in synthetic_present:
        train_wfs = [wf for fam in synthetic_present if fam != held_out
                     for insts in by_family[fam].values() for _, wf in insts]
        test_instances = sorted((wf for insts in by_family[held_out].values() for _, wf in insts),
                                 key=lambda wf: wf.num_tasks)
        for test_wf in test_instances[:max_test_per_family]:
            rows += _score_against(train_wfs, test_wf, environment, train_seeds, eval_seeds,
                                    pop_size, max_evals, policy_episodes, beta, vns_mu,
                                    "lowo", f"all synthetic except {held_out}")
    return rows


def run_cross_scale(by_family, environment, train_seeds, eval_seeds, pop_size, max_evals,
                     policy_episodes, beta, vns_mu, max_test_per_family: int,
                     max_test_scales: int = 10 ** 9) -> list[dict]:
    rows = []
    for family, by_scale in by_family.items():
        scales = sorted(by_scale)
        if len(scales) < 2:
            print(f"  [skip] cross-scale/{family}: need >=2 scales, found {scales}")
            continue
        train_scale = scales[0]
        train_wfs = [wf for _, wf in by_scale[train_scale]]
        # test_scale > train_scale means a bigger (costlier-per-run) test
        # workflow every time (generate_instances.py's scales are 100 <
        # 500 < 1000), so max_test_scales bounds how many of those pricier
        # scales a smoke run actually touches -- unlike max_test_per_family,
        # this can't be worked around by picking "smaller" instances first.
        for test_scale in scales[1:][:max_test_scales]:
            test_instances = [wf for _, wf in by_scale[test_scale]]
            for test_wf in test_instances[:max_test_per_family]:
                rows += _score_against(train_wfs, test_wf, environment, train_seeds, eval_seeds,
                                        pop_size, max_evals, policy_episodes, beta, vns_mu,
                                        "cross-scale", f"{family}@{train_scale} -> {family}@{test_scale}")
    return rows


def run_zero_shot(by_family, environment, train_seeds, eval_seeds, pop_size, max_evals,
                   policy_episodes, beta, vns_mu, max_test_per_family: int) -> list[dict]:
    rows = []
    synthetic_present = [f for f in by_family if f in SYNTHETIC_FAMILIES]
    real_present = [f for f in by_family if f in REAL_TRACE_FAMILIES]
    if not real_present:
        print("  [skip] zero-shot: no real WfCommons trace instances found under data/instances/ "
              "-- see data/instances/README.md to fetch/convert one of "
              f"{REAL_TRACE_FAMILIES} with scripts/convert_wfcommons_trace.py")
        return rows
    train_wfs = [wf for fam in synthetic_present
                 for insts in by_family[fam].values() for _, wf in insts]
    for real_family in real_present:
        test_instances = sorted((wf for insts in by_family[real_family].values() for _, wf in insts),
                                 key=lambda wf: wf.num_tasks)
        for test_wf in test_instances[:max_test_per_family]:
            rows += _score_against(train_wfs, test_wf, environment, train_seeds, eval_seeds,
                                    pop_size, max_evals, policy_episodes, beta, vns_mu,
                                    "zero-shot", f"all synthetic -> {real_family}")
    return rows


PROTOCOLS = {
    "in-family": run_in_family,
    "lowo": run_lowo,
    "cross-scale": run_cross_scale,
    "zero-shot": run_zero_shot,
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--instances-glob", default=os.path.join(ROOT, "data/instances/*/*.json"))
    ap.add_argument("--seeds-file", default=os.path.join(ROOT, "data/seeds/seeds.json"))
    ap.add_argument("--out", default=os.path.join(ROOT, "results/transfer_results.csv"))
    ap.add_argument("--protocol", choices=list(PROTOCOLS) + ["all"], default="all")
    ap.add_argument("--full", action="store_true",
                     help="paper's protocol scale (pop_size=70, max_evals=7340, all 30 seeds) -- slow")
    ap.add_argument("--n-seeds", type=int, default=2, help="ignored with --full")
    ap.add_argument("--max-test-per-family", type=int, default=2,
                     help="cap on held-out test instances scored per family per protocol "
                          "(keeps this fast outside --full; every held-out instance is still "
                          "scored at least once in --full)")
    ap.add_argument("--max-families", type=int, default=3,
                     help="cap on how many synthetic families each protocol touches outside "
                          "--full (real-trace families, if any, are never trimmed by this); "
                          "cross-scale in particular runs its test instances at a *larger* "
                          "scale than training, so touching every family here is expensive "
                          "even at a small max_evals -- ignored with --full")
    ap.add_argument("--vns-mu", type=int, default=5)
    ap.add_argument("--beta", type=float, default=0.5)
    args = ap.parse_args()

    by_family = load_instances(args.instances_glob)
    if not by_family:
        print("no instances found -- run scripts/generate_instances.py first", file=sys.stderr)
        sys.exit(1)

    seeds = load_seeds(args.seeds_file)
    if args.full:
        pop_size, max_evals, policy_episodes = 70, 7340, 400
        eval_seeds = seeds["evaluation"]
        train_seeds = seeds["training"]
        max_test_per_family = 10 ** 9
        max_test_scales = 10 ** 9
    else:
        # kept tiny -- each (protocol, test instance, seed) pair here runs
        # *two* full GSMADE searches (transferred_policy and no_policy),
        # on top of a fresh multi-workflow policy pretrain per (protocol,
        # test instance); see scripts/run_evaluation.py's matching comment
        pop_size, max_evals, policy_episodes = 8, 100, 15
        eval_seeds = seeds["evaluation"][: args.n_seeds]
        train_seeds = seeds["training"][: max(1, args.n_seeds)]
        max_test_per_family = args.max_test_per_family
        max_test_scales = 1
        real_fams = {f: v for f, v in by_family.items() if f in REAL_TRACE_FAMILIES}
        synth_fams = {f: v for f, v in by_family.items() if f in SYNTHETIC_FAMILIES}
        trimmed_synth = dict(list(synth_fams.items())[: args.max_families])
        by_family = {**trimmed_synth, **real_fams}
        print(f"[smoke mode] {len(eval_seeds)} seed(s), pop_size={pop_size}, max_evals={max_evals}, "
              f"<= {max_test_per_family} held-out instance(s)/family/protocol, "
              f"<= {args.max_families} synthetic famil(y/ies) touched, cross-scale tests "
              f"<= {max_test_scales} larger scale -- pass --full for scale")

    environment = load_environment()
    protocols = list(PROTOCOLS) if args.protocol == "all" else [args.protocol]

    all_rows = []
    for name in protocols:
        print(f"=== protocol: {name} ===")
        extra = {"max_test_scales": max_test_scales} if name == "cross-scale" else {}
        rows = PROTOCOLS[name](by_family, environment, train_seeds, eval_seeds, pop_size, max_evals,
                                policy_episodes, args.beta, args.vns_mu, max_test_per_family, **extra)
        all_rows.extend(rows)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df = pd.DataFrame(all_rows)
    df.to_csv(args.out, index=False)
    print(f"\nwrote {args.out} ({len(df)} rows)")


if __name__ == "__main__":
    main()
