#!/usr/bin/env python3
"""Synthetic workflow generators for the five Pegasus-style families.

Honest scope note: these are NOT the actual Pegasus synthetic workflow
generator the paper cites (Juve et al., reference [23]) -- that is a
separate tool maintained by the Pegasus project, generating instances
from empirically profiled real executions. What's here is a lightweight,
documented structural approximation of each family's known topology
(fan-out/fan-in pattern, relative depth and width), parameterized by
instance scale, so the rest of this repo has real, runnable, variously-
shaped DAGs to search over out of the box. If you have access to the
real Pegasus generator or real WfCommons traces, generate/convert your
instances with scripts/convert_wfcommons_trace.py and drop them in
data/instances/ instead -- nothing downstream cares which source an
instance file came from.

Each family is a layered DAG (list of levels, each a list of task ids)
with edges only between adjacent levels, built from three knobs:
  depth_levels   -- how many levels (controls Table 2's "Depth" column)
  width_profile  -- relative width of each level as a fraction of
                     num_tasks, normalized to sum to 1 (controls "Max
                     width" and the overall fan-out/fan-in shape)
  fanout_density -- mean number of edges per task to the next level
"""
from __future__ import annotations

import networkx as nx
import numpy as np

from gsmade.workflow import Task, Workflow

FAMILY_PRESETS = {
    # depth_levels, width_profile (shape, not exact counts), fanout_density
    "Montage":      dict(depth_levels=9, width_shape="wide-middle", fanout_density=3.0,
                          workload_range=(50, 400), data_range=(1, 25)),
    "CyberShake":   dict(depth_levels=5, width_shape="early-wide", fanout_density=2.0,
                          workload_range=(100, 800), data_range=(5, 60)),
    "Epigenomics":  dict(depth_levels=8, width_shape="parallel-pipelines", fanout_density=1.3,
                          workload_range=(200, 1500), data_range=(10, 120)),
    "LIGO_Inspiral": dict(depth_levels=6, width_shape="balanced-tree", fanout_density=2.2,
                           workload_range=(80, 600), data_range=(2, 40)),
    "SIPHT":        dict(depth_levels=4, width_shape="very-wide", fanout_density=1.5,
                          workload_range=(20, 200), data_range=(1, 15)),
}


def _level_sizes(num_tasks: int, depth_levels: int, width_shape: str, rng: np.random.Generator) -> list[int]:
    levels = np.ones(depth_levels)
    mid = depth_levels / 2.0
    if width_shape == "wide-middle":
        levels = np.array([1.0 + 3.0 * np.exp(-((i - mid) ** 2) / (2 * (mid / 1.5) ** 2))
                            for i in range(depth_levels)])
    elif width_shape == "early-wide":
        levels = np.array([4.0 * np.exp(-i / 1.5) + 0.3 for i in range(depth_levels)])
    elif width_shape == "parallel-pipelines":
        # several short parallel chains merging at the end: constant width
        # until the last level, which narrows sharply
        levels = np.array([3.0] * (depth_levels - 1) + [0.5])
    elif width_shape == "balanced-tree":
        half = depth_levels // 2
        up = [2.0 ** i for i in range(half)]
        down = list(reversed(up))[: depth_levels - half]
        levels = np.array((up + down)[:depth_levels], dtype=float)
    elif width_shape == "very-wide":
        levels = np.array([6.0] * (depth_levels - 1) + [0.4])
    levels = levels / levels.sum()
    sizes = np.maximum(1, np.round(levels * (num_tasks - 2))).astype(int)  # reserve root+sink
    # adjust to hit num_tasks - 2 exactly (root and sink added separately)
    while sizes.sum() > num_tasks - 2:
        sizes[int(np.argmax(sizes))] -= 1
    while sizes.sum() < num_tasks - 2:
        sizes[int(np.argmin(sizes))] += 1
    return [1] + list(sizes) + [1]  # explicit single root and single sink level


def generate(family: str, num_tasks: int, seed: int) -> Workflow:
    if family not in FAMILY_PRESETS:
        raise ValueError(f"unknown family: {family}")
    preset = FAMILY_PRESETS[family]
    rng = np.random.default_rng(seed)

    sizes = _level_sizes(num_tasks, preset["depth_levels"], preset["width_shape"], rng)
    g = nx.DiGraph()
    tasks: dict[int, Task] = {}
    tid = 0
    levels: list[list[int]] = []
    for sz in sizes:
        level = []
        for _ in range(sz):
            wl = float(rng.uniform(*preset["workload_range"]))
            g.add_node(tid)
            tasks[tid] = Task(tid, f"{family}_t{tid}", workload_mi=wl)
            level.append(tid)
            tid += 1
        levels.append(level)

    for li in range(len(levels) - 1):
        src_level, dst_level = levels[li], levels[li + 1]
        for dst in dst_level:
            n_in = max(1, min(len(src_level), int(round(rng.poisson(preset["fanout_density"]) + 1))))
            parents = rng.choice(src_level, size=n_in, replace=False)
            for p in parents:
                data_mb = float(rng.uniform(*preset["data_range"]))
                g.add_edge(int(p), dst, data_mb=data_mb)
    # guarantee weak connectivity: any dst with no parent gets the nearest
    # previous level's first node as a fallback parent
    for li in range(1, len(levels)):
        for dst in levels[li]:
            if g.in_degree(dst) == 0:
                g.add_edge(levels[li - 1][0], dst, data_mb=float(rng.uniform(*preset["data_range"])))

    assert nx.is_directed_acyclic_graph(g)
    wf = Workflow(name=f"{family}_{num_tasks}", family=family, graph=g, tasks=tasks, deadline_factor=1.5)
    return wf
