#!/usr/bin/env python3
"""Regenerate figures from this repository's own runs: results/*.png.

Honesty note -- read this before trusting or extending these figures:
  - fig_pareto_fronts.png and fig_ablation_arms.png are built from
    results/fronts.json / results/ablation_results.csv, i.e. from
    whatever scale you last ran scripts/run_evaluation.py /
    run_ablation.py at. A smoke-mode run gives a thin, noisy picture;
    pass --full on those scripts first for a figure worth reading.
  - fig_beta_sensitivity.png is not read from a CSV: this script runs a
    small live sweep over GSMADEConfig.seeding_fraction (beta) on one
    instance, because no upstream script already produces that sweep.
    It is the same kind of experiment as Fig. 2(d)'s beta axis, just
    computed on demand here rather than cached to disk; --full makes it
    slower, not different in kind. ρ and μ sweep the same way (same
    GSMADEConfig fields) -- not wired up here to keep this script's
    runtime bounded; see _sweep_beta() below if you want to copy the
    pattern for either.
  - What this script does NOT attempt, and why:
      * Fig. 2(a) (validation hypervolume / deadline-satisfaction vs.
        training epoch) and Fig. 2(b) (ROC for deadline-feasibility
        screening) need a trained feasibility classifier and periodic
        in-training evaluation checkpoints that this repository does
        not instrument. Building a plausible-looking curve without
        that machinery would be fabricating a result, not regenerating
        one, so these panels are left out.
      * Fig. 2(c) ("cost of removing one neighbourhood") would ablate
        gsmade/vns.py's four N1-N4 moves one at a time; this repo's
        VNS does not expose a flag to disable one neighbourhood (see
        gsmade/vns.py), so it is left out rather than faked. The
        ablation that *is* wired up (arms A1-A5, not individual
        neighbourhoods) is fig_ablation_arms.png above.
      * Figure 3 (task placement by tier on the real 1000Genome
        instance) is a qualitative read of one specific real
        deployment's schedule; it needs that real trace (see
        data/instances/README.md) plus a human-readable per-tier
        tabulation this script doesn't build. Convert the trace and
        the per-run tier assignment is already computable from
        gsmade.encoding.decode()'s `assignment` array -- left as a
        follow-up, not fabricated here.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from _common import ROOT, load_environment, load_seeds, pretrain_policy, smallest_first  # noqa: E402

from gsmade.encoding import chromosome_length
from gsmade.lshade import LSHADEConfig
from gsmade.scheduler import GSMADE, GSMADEConfig
from gsmade.workflow import Workflow


def fig_pareto_fronts(fronts_path: str, out_path: str) -> bool:
    if not os.path.exists(fronts_path):
        print(f"  [skip] {out_path}: {fronts_path} not found -- run scripts/run_evaluation.py first")
        return False
    with open(fronts_path) as f:
        fronts = json.load(f)
    if not fronts:
        print(f"  [skip] {out_path}: {fronts_path} is empty")
        return False

    instance = next(iter(fronts))
    seed = next(iter(fronts[instance]))
    by_method = fronts[instance][seed]

    fig, ax = plt.subplots(figsize=(7, 5))
    for method, points in sorted(by_method.items()):
        if not points:
            continue
        arr = np.asarray(points, dtype=float)
        marker = "*" if method == "GS-MADE" else "o"
        size = 90 if method == "GS-MADE" else 28
        ax.scatter(arr[:, 0], arr[:, 1], s=size, marker=marker, alpha=0.75, label=method)
    ax.set_xlabel("Makespan (s)")
    ax.set_ylabel("Energy (J)")
    ax.set_title(f"Pareto fronts -- {instance}, seed {seed}\n(makespan vs. energy projection; "
                 "cost is the omitted 3rd objective)")
    ax.legend(fontsize=7, ncol=2, loc="best")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    print(f"  wrote {out_path}")
    return True


def fig_ablation_arms(ablation_path: str, out_path: str) -> bool:
    if not os.path.exists(ablation_path):
        print(f"  [skip] {out_path}: {ablation_path} not found -- run scripts/run_ablation.py first")
        return False
    df = pd.read_csv(ablation_path)
    if df.empty:
        print(f"  [skip] {out_path}: {ablation_path} is empty")
        return False
    agg = df.groupby("arm")["hypervolume"].agg(["mean", "std"]).reindex(["A1", "A2", "A3", "A4", "A5"]).dropna(how="all")

    fig, ax = plt.subplots(figsize=(6, 4.5))
    colors = ["#888888", "#6a9fb5", "#b58a6a", "#c97a7a", "#4a9f6a"]
    ax.bar(agg.index, agg["mean"], yerr=agg["std"].fillna(0.0), capsize=4,
           color=colors[: len(agg)])
    ax.set_ylabel("Mean hypervolume")
    ax.set_title("Ablation: ablation arms A1-A5\n(this repo's analogue of Table 6, as a bar chart)")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    print(f"  wrote {out_path}")
    return True


def _sweep_beta(workflow: Workflow, environment, policy, seed: int, pop_size: int, max_evals: int,
                 vns_mu: int, betas: list[float]) -> list[dict]:
    rows = []
    for beta in betas:
        cfg = GSMADEConfig(
            lshade=LSHADEConfig(dim=chromosome_length(workflow), pop_size_init=pop_size,
                                 pop_size_min=max(6, pop_size // 5), max_evals=max_evals),
            seeding_fraction=beta, elite_fraction=0.2, vns_period=vns_mu,
        )
        gsm = GSMADE(workflow, environment, cfg, policy if beta > 0 else None,
                     np.random.default_rng(seed))
        result = gsm.run()
        from gsmade import metrics
        front = result["front"]
        hv = metrics.hypervolume(front, metrics.reference_point(front, 95.0)) if front else 0.0
        rows.append({"beta": beta, "hypervolume": hv, "evals_used": result["evals_used"]})
    return rows


def fig_beta_sensitivity(instances_glob: str, seeds_file: str, out_path: str,
                          pop_size: int, max_evals: int, policy_episodes: int, seed_arg: int) -> bool:
    import glob
    # smallest_first, not a plain sort: see its docstring in _common.py
    instance_paths = smallest_first(glob.glob(instances_glob))
    if not instance_paths:
        print(f"  [skip] {out_path}: no instances found under {instances_glob}")
        return False
    wf = Workflow.load(instance_paths[0])
    seeds = load_seeds(seeds_file)
    environment = load_environment()
    policy = pretrain_policy(wf, environment, seeds["training"][:1], policy_episodes, hidden_dim=16)

    betas = [0.0, 0.25, 0.5, 0.75, 1.0]
    rows = _sweep_beta(wf, environment, policy, seed_arg, pop_size, max_evals, vns_mu=5, betas=betas)
    df = pd.DataFrame(rows)

    fig, ax1 = plt.subplots(figsize=(6.5, 4.5))
    ax1.plot(df["beta"], df["hypervolume"], "o-", color="#4a9f6a", label="Hypervolume")
    ax1.set_xlabel(r"Seeding fraction $\beta$")
    ax1.set_ylabel("Hypervolume", color="#4a9f6a")
    ax2 = ax1.twinx()
    ax2.plot(df["beta"], df["evals_used"], "s--", color="#6a9fb5", label="Evals used")
    ax2.set_ylabel("Evaluations used", color="#6a9fb5")
    ax1.set_title(f"Sensitivity to seeding fraction beta -- {wf.name}\n"
                  "(same pattern applies to rho=elite_fraction and mu=vns_period)")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    print(f"  wrote {out_path}")
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fronts", default=os.path.join(ROOT, "results/fronts.json"))
    ap.add_argument("--ablation", default=os.path.join(ROOT, "results/ablation_results.csv"))
    ap.add_argument("--instances-glob", default=os.path.join(ROOT, "data/instances/*/*.json"))
    ap.add_argument("--seeds-file", default=os.path.join(ROOT, "data/seeds/seeds.json"))
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "results"))
    ap.add_argument("--full", action="store_true", help="paper's protocol scale for the live beta sweep")
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--skip-beta-sweep", action="store_true",
                     help="skip the live GS-MADE runs for fig_beta_sensitivity.png (fast)")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    print("=== fig_pareto_fronts.png ===")
    fig_pareto_fronts(args.fronts, os.path.join(args.out_dir, "fig_pareto_fronts.png"))

    print("=== fig_ablation_arms.png ===")
    fig_ablation_arms(args.ablation, os.path.join(args.out_dir, "fig_ablation_arms.png"))

    print("=== fig_beta_sensitivity.png ===")
    if args.skip_beta_sweep:
        print("  [skip] --skip-beta-sweep passed")
    else:
        # 5 live GSMADE runs (one per beta value) -- kept tiny by default
        # since real instances are >=100 tasks; see scripts/run_evaluation.py's
        # matching comment on why smoke-mode budgets are this small
        pop_size, max_evals, policy_episodes = (70, 7340, 400) if args.full else (8, 100, 15)
        fig_beta_sensitivity(args.instances_glob, args.seeds_file,
                              os.path.join(args.out_dir, "fig_beta_sensitivity.png"),
                              pop_size, max_evals, policy_episodes, args.seed)

    print("\nSee this script's module docstring for which paper figure panels (2(a), 2(b), "
          "2(c), Figure 3) are intentionally not produced here, and why.")


if __name__ == "__main__":
    main()
