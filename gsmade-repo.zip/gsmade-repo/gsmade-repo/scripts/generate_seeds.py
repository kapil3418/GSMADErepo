#!/usr/bin/env python3
"""Generate the evaluation seed block and a disjoint policy-training seed
block (paper: "the 30 seeds ... Policy training draws on a generator-
seed block disjoint from the 30 evaluation seeds").

The paper's own text shows the evaluation block as "{11, 23, 37, ...,
331}" -- 30 strictly increasing integers starting at 11 and ending at
331, with 23 and 37 fixed as the second and third values. This script
reproduces exactly that shape deterministically from one documented
meta-seed (below), rather than inventing an unrelated list, so the file
it writes is a faithful, regeneratable stand-in for the original. If you
are an author of the paper and have the real recorded seed list, replace
data/seeds/seeds.json's "evaluation" array directly -- nothing else in
this repo cares how that file was produced, only that it exists and is
reused consistently (every result in Tables 4/5/8/9 and Figs. 2-3 must
come from the same 30 seeds for the comparisons to be meaningful).

The training block (used only by gsmade/gat_policy.py's REINFORCE
trainer and the DQN/PPO baselines) is a separate, non-overlapping range
entirely, so no evaluation seed can leak into policy training.
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np

META_SEED = 1707  # documented, fixed; change only if you intend to
                    # regenerate a *different* reproducible seed block


def build_evaluation_seeds(n_total: int = 30, first_two: tuple = (11, 23, 37), last: int = 331) -> list[int]:
    rng = np.random.default_rng(META_SEED)
    fixed_head = list(first_two)
    n_middle = n_total - len(fixed_head) - 1
    middle = sorted(rng.choice(np.arange(fixed_head[-1] + 1, last), size=n_middle, replace=False).tolist())
    seeds = fixed_head + middle + [last]
    assert len(seeds) == n_total and seeds == sorted(set(seeds))
    return [int(s) for s in seeds]


def build_training_seeds(n_total: int, eval_seeds: set[int], start: int = 1000) -> list[int]:
    rng = np.random.default_rng(META_SEED + 1)
    pool = [s for s in range(start, start + 10 * n_total) if s not in eval_seeds]
    chosen = sorted(rng.choice(pool, size=n_total, replace=False).tolist())
    assert set(chosen).isdisjoint(eval_seeds)
    return [int(s) for s in chosen]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..", "data", "seeds", "seeds.json"))
    ap.add_argument("--n-training-seeds", type=int, default=200)
    args = ap.parse_args()

    evaluation = build_evaluation_seeds()
    training = build_training_seeds(args.n_training_seeds, set(evaluation))

    payload = {
        "meta_seed": META_SEED,
        "evaluation": evaluation,
        "training": training,
        "note": "evaluation seeds used by every scripts/run_*.py evaluation; "
                "training seeds used only by gsmade/gat_policy.py's REINFORCE "
                "trainer and the DQN/PPO baselines. Disjoint by construction.",
    }
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(payload, f, indent=2)
    print(f"wrote {args.out}")
    print(f"  evaluation ({len(evaluation)}): {evaluation}")
    print(f"  training   ({len(training)}): first 10 shown: {training[:10]} ...")


if __name__ == "__main__":
    main()
