"""A minimal, dependency-free (NumPy-only) reverse-mode autodiff engine.

This repo keeps its neural components (the GAT seeding policy, and the
DQN / PPO baselines of Table 2b) on pure NumPy rather than PyTorch so
that `pip install -r requirements.txt` stays small and the whole
pipeline runs on a laptop CPU with no extra wheel to fetch. Every
primitive op below is unit-tested against a finite-difference gradient
check in tests/test_nn.py. See README.md "Swapping in PyTorch" if you
want a GPU-accelerated drop-in replacement for large-scale training.

Design: a small ``Tensor`` class records the ops that produced it (a
tape), and ``Tensor.backward()`` walks the tape in reverse topological
order accumulating gradients -- the same idea as micrograd, extended to
N-d NumPy arrays with broadcasting.
"""
from __future__ import annotations

import numpy as np


def _unbroadcast(grad: np.ndarray, shape: tuple) -> np.ndarray:
    """Reduce `grad` (whose shape may have been broadcast during the
    forward op) back down to `shape` by summing over the broadcast axes."""
    while grad.ndim > len(shape):
        grad = grad.sum(axis=0)
    for i, s in enumerate(shape):
        if s == 1 and grad.shape[i] != 1:
            grad = grad.sum(axis=i, keepdims=True)
    return grad


class Tensor:
    __slots__ = ("data", "grad", "requires_grad", "_backward", "_prev")

    def __init__(self, data, requires_grad: bool = False, _children: tuple = ()):
        self.data = np.asarray(data, dtype=np.float64)
        self.requires_grad = requires_grad or any(c.requires_grad for c in _children)
        self.grad = np.zeros_like(self.data) if self.requires_grad else None
        self._backward = lambda: None
        self._prev = _children

    @property
    def shape(self):
        return self.data.shape

    # ---- graph traversal ---------------------------------------------
    def backward(self):
        assert self.data.shape == () or self.data.size == 1, "backward() requires a scalar loss"
        topo, visited = [], set()

        def build(v):
            if id(v) not in visited:
                visited.add(id(v))
                for c in v._prev:
                    build(c)
                topo.append(v)
        build(self)
        self.grad = np.ones_like(self.data)
        for v in reversed(topo):
            v._backward()

    def zero_grad(self):
        if self.requires_grad:
            self.grad = np.zeros_like(self.data)

    # ---- ops ------------------------------------------------------------
    def __add__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data + other.data, _children=(self, other))

        def _backward():
            if self.requires_grad:
                self.grad += _unbroadcast(out.grad, self.data.shape)
            if other.requires_grad:
                other.grad += _unbroadcast(out.grad, other.data.shape)
        out._backward = _backward
        return out

    __radd__ = __add__

    def __neg__(self):
        out = Tensor(-self.data, _children=(self,))

        def _backward():
            if self.requires_grad:
                self.grad += -out.grad
        out._backward = _backward
        return out

    def __sub__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        return self + (-other)

    def __rsub__(self, other):
        return Tensor(other) - self

    def __mul__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data * other.data, _children=(self, other))

        def _backward():
            if self.requires_grad:
                self.grad += _unbroadcast(out.grad * other.data, self.data.shape)
            if other.requires_grad:
                other.grad += _unbroadcast(out.grad * self.data, other.data.shape)
        out._backward = _backward
        return out

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        return self * other.pow(-1.0)

    def __pow__(self, p: float):
        return self.pow(p)

    def pow(self, p: float):
        out = Tensor(self.data ** p, _children=(self,))

        def _backward():
            if self.requires_grad:
                self.grad += _unbroadcast(out.grad * p * (self.data ** (p - 1)), self.data.shape)
        out._backward = _backward
        return out

    def __matmul__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data @ other.data, _children=(self, other))

        def _backward():
            if self.requires_grad:
                self.grad += out.grad @ other.data.T
            if other.requires_grad:
                other.grad += self.data.T @ out.grad
        out._backward = _backward
        return out

    def sum(self, axis=None, keepdims=False):
        out = Tensor(self.data.sum(axis=axis, keepdims=keepdims), _children=(self,))

        def _backward():
            if self.requires_grad:
                g = out.grad
                if not keepdims and axis is not None:
                    g = np.expand_dims(g, axis)
                self.grad += np.broadcast_to(g, self.data.shape)
        out._backward = _backward
        return out

    def mean(self):
        n = self.data.size
        return self.sum() * (1.0 / n)

    def relu(self):
        out = Tensor(np.maximum(self.data, 0.0), _children=(self,))

        def _backward():
            if self.requires_grad:
                self.grad += out.grad * (self.data > 0)
        out._backward = _backward
        return out

    def leaky_relu(self, slope: float = 0.2):
        out = Tensor(np.where(self.data > 0, self.data, slope * self.data), _children=(self,))

        def _backward():
            if self.requires_grad:
                self.grad += out.grad * np.where(self.data > 0, 1.0, slope)
        out._backward = _backward
        return out

    def tanh(self):
        t = np.tanh(self.data)
        out = Tensor(t, _children=(self,))

        def _backward():
            if self.requires_grad:
                self.grad += out.grad * (1 - t ** 2)
        out._backward = _backward
        return out

    def sigmoid(self):
        s = 1.0 / (1.0 + np.exp(-self.data))
        out = Tensor(s, _children=(self,))

        def _backward():
            if self.requires_grad:
                self.grad += out.grad * s * (1 - s)
        out._backward = _backward
        return out

    def exp(self):
        e = np.exp(self.data)
        out = Tensor(e, _children=(self,))

        def _backward():
            if self.requires_grad:
                self.grad += out.grad * e
        out._backward = _backward
        return out

    def log(self):
        out = Tensor(np.log(self.data + 1e-12), _children=(self,))

        def _backward():
            if self.requires_grad:
                self.grad += out.grad / (self.data + 1e-12)
        out._backward = _backward
        return out

    def softmax(self, axis=-1):
        z = self.data - self.data.max(axis=axis, keepdims=True)
        e = np.exp(z)
        s = e / e.sum(axis=axis, keepdims=True)
        out = Tensor(s, _children=(self,))

        def _backward():
            if self.requires_grad:
                # d softmax_i/d x_j = s_i (delta_ij - s_j); contracted with
                # upstream grad along `axis` without materializing the full
                # Jacobian: g_x = s * (g_out - sum(g_out * s, axis))
                dot = (out.grad * s).sum(axis=axis, keepdims=True)
                self.grad += s * (out.grad - dot)
        out._backward = _backward
        return out

    def reshape(self, shape):
        out = Tensor(self.data.reshape(shape), _children=(self,))

        def _backward():
            if self.requires_grad:
                self.grad += out.grad.reshape(self.data.shape)
        out._backward = _backward
        return out

    def __getitem__(self, idx):
        out = Tensor(self.data[idx], _children=(self,))

        def _backward():
            if self.requires_grad:
                np.add.at(self.grad, idx, out.grad)
        out._backward = _backward
        return out

    @staticmethod
    def concat(tensors: list["Tensor"], axis: int = 0) -> "Tensor":
        out = Tensor(np.concatenate([t.data for t in tensors], axis=axis), _children=tuple(tensors))
        sizes = [t.data.shape[axis] for t in tensors]

        def _backward():
            offset = 0
            for t, sz in zip(tensors, sizes):
                if t.requires_grad:
                    sl = [slice(None)] * out.data.ndim
                    sl[axis] = slice(offset, offset + sz)
                    t.grad += out.grad[tuple(sl)]
                offset += sz
        out._backward = _backward
        return out


# --------------------------------------------------------------------------
# Layers and optimizer
# --------------------------------------------------------------------------
class Linear:
    def __init__(self, in_dim: int, out_dim: int, rng: np.random.Generator):
        limit = np.sqrt(6.0 / (in_dim + out_dim))  # Glorot uniform
        self.W = Tensor(rng.uniform(-limit, limit, size=(in_dim, out_dim)), requires_grad=True)
        self.b = Tensor(np.zeros(out_dim), requires_grad=True)

    def __call__(self, x: Tensor) -> Tensor:
        return x @ self.W + self.b

    def params(self) -> list[Tensor]:
        return [self.W, self.b]


class MLP:
    def __init__(self, dims: list[int], rng: np.random.Generator, out_activation=None):
        self.layers = [Linear(dims[i], dims[i + 1], rng) for i in range(len(dims) - 1)]
        self.out_activation = out_activation

    def __call__(self, x: Tensor) -> Tensor:
        for i, layer in enumerate(self.layers):
            x = layer(x)
            if i < len(self.layers) - 1:
                x = x.relu()
            elif self.out_activation is not None:
                x = getattr(x, self.out_activation)()
        return x

    def params(self) -> list[Tensor]:
        out = []
        for layer in self.layers:
            out.extend(layer.params())
        return out


class Adam:
    def __init__(self, params: list[Tensor], lr: float = 1e-3, betas=(0.9, 0.999), eps: float = 1e-8):
        self.params = params
        self.lr = lr
        self.b1, self.b2 = betas
        self.eps = eps
        self.m = [np.zeros_like(p.data) for p in params]
        self.v = [np.zeros_like(p.data) for p in params]
        self.t = 0

    def zero_grad(self):
        for p in self.params:
            p.zero_grad()

    def step(self):
        self.t += 1
        for i, p in enumerate(self.params):
            g = p.grad
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * (g ** 2)
            m_hat = self.m[i] / (1 - self.b1 ** self.t)
            v_hat = self.v[i] / (1 - self.b2 ** self.t)
            p.data -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)
