"""Cold-start L-SHADE (Tanabe & Fukunaga, 2014 -- reference [15]):
exactly GS-MADE's own Stage B1 search, started from a uniformly random
population instead of the GAT-seeded one -- Table 2b's own description,
and Table 6's ablation arm A1."""
from __future__ import annotations

import numpy as np

from ..encoding import chromosome_length
from ..environment import Environment
from ..lshade import LSHADEConfig
from ..scheduler import GSMADE, GSMADEConfig
from ..workflow import Workflow
from . import BaselineResult


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator,
        pop_size: int = 30, max_evals: int = 3000, **kwargs) -> BaselineResult:
    cfg = GSMADEConfig(
        lshade=LSHADEConfig(dim=chromosome_length(workflow), pop_size_init=pop_size,
                             pop_size_min=max(6, pop_size // 5), max_evals=max_evals),
        seeding_fraction=0.0, vns_period=None,
    )
    gsm = GSMADE(workflow, environment, cfg, policy=None, rng=rng)
    result = gsm.run()
    return BaselineResult("cold-start L-SHADE", result["archive_individuals"], result["evals_used"])
