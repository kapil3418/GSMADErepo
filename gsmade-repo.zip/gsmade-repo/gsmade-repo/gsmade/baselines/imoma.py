"""IMOMA (reference [2]). Table 2b: "own operators retained; objective
count widened to three." The source paper embeds bi-objective local-
search operators inside an evolutionary loop with opposition-based
learning; kept here as NSGA-II's evolutionary loop (same SBX/polynomial
operators every GA-style baseline uses) plus (a) opposition-based
population initialization and (b) a per-generation local-search pass on
a fraction of the offspring -- the two operators the paper's related-
work section attributes to IMOMA -- widened from its original two
objectives to this repo's three throughout.
"""
from __future__ import annotations

import numpy as np

from ..encoding import chromosome_length
from ..environment import Environment
from ..lshade import Individual, environmental_selection, non_dominated_sort
from ..workflow import Workflow
from . import BaselineResult
from .moea_common import evaluate_all, make_evaluate_fn
from .nsga2 import _poly_mutate, _rank_and_crowd, _sbx, _tournament

LOCAL_SEARCH_FRACTION = 0.3
LOCAL_SEARCH_STEP = 0.05


def _opposition_based_init(dim: int, pop_size: int, rng: np.random.Generator) -> list[Individual]:
    half = pop_size // 2
    base = [rng.random(dim) for _ in range(half)]
    opposite = [1.0 - g for g in base]
    return [Individual(g) for g in base + opposite][:pop_size] or [Individual(rng.random(dim))]


def _local_search(ind: Individual, evaluate_fn, rng: np.random.Generator) -> tuple[Individual, int]:
    from ..lshade import dominates
    perturb = rng.normal(0, LOCAL_SEARCH_STEP, size=ind.genes.shape)
    cand_genes = np.clip(ind.genes + perturb, 0.0, 0.999999)
    cand_obj = evaluate_fn(cand_genes)
    if dominates(cand_obj, ind.objectives):
        return Individual(cand_genes, cand_obj), 1
    return ind, 1


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator,
        pop_size: int = 30, max_evals: int = 3000, **kwargs) -> BaselineResult:
    dim = chromosome_length(workflow)
    evaluate_fn = make_evaluate_fn(workflow, environment)

    pop = _opposition_based_init(dim, pop_size, rng)
    evals = evaluate_all(pop, evaluate_fn)
    pop = environmental_selection(pop, pop_size) if len(pop) > pop_size else pop
    mutation_p = 1.0 / dim

    while evals < max_evals:
        rank, dist = _rank_and_crowd(pop)
        offspring: list[Individual] = []
        while len(offspring) < pop_size and evals < max_evals:
            p1 = _tournament(pop, rank, dist, rng)
            p2 = _tournament(pop, rank, dist, rng)
            c1, c2 = _sbx(p1.genes, p2.genes, rng)
            c1, c2 = _poly_mutate(c1, mutation_p, rng), _poly_mutate(c2, mutation_p, rng)
            for c in (c1, c2):
                if evals >= max_evals:
                    break
                obj = evaluate_fn(c)
                evals += 1
                offspring.append(Individual(c, obj))

        n_ls = int(round(LOCAL_SEARCH_FRACTION * len(offspring)))
        ls_idx = rng.choice(len(offspring), size=min(n_ls, len(offspring)), replace=False) if offspring else []
        for i in ls_idx:
            if evals >= max_evals:
                break
            offspring[i], used = _local_search(offspring[i], evaluate_fn, rng)
            evals += used

        pop = environmental_selection(pop + offspring, pop_size)

    fronts = non_dominated_sort(pop)
    return BaselineResult("IMOMA", [pop[i] for i in fronts[0]], evals)
