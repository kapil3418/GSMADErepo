"""Multi-objective grey wolf optimizer. Alpha/beta/delta leaders are the
three most diverse members (by crowding distance) of a running external
archive of non-dominated solutions; every wolf's position is pulled
toward the average of the three leaders' encircling updates, with the
exploration coefficient `a` linearly annealed from 2 to 0 over the run,
exactly as in the single-objective original."""
from __future__ import annotations

import numpy as np

from ..encoding import chromosome_length
from ..lshade import ExternalArchive, Individual, crowding_distance, non_dominated_sort
from ..environment import Environment
from ..workflow import Workflow
from . import BaselineResult
from .moea_common import evaluate_all, init_population, make_evaluate_fn


def _pick_leaders(archive: ExternalArchive, pop: list[Individual], rng) -> list[Individual]:
    pool = archive.members if len(archive.members) >= 3 else pop
    if len(pool) <= 3:
        return (pool * 3)[:3]
    fronts = non_dominated_sort(pool)
    front0 = fronts[0]
    dist = crowding_distance(pool, front0)
    ranked = sorted(front0, key=lambda i: -dist[i])
    if len(ranked) >= 3:
        return [pool[i] for i in ranked[:3]]
    extra = [i for i in range(len(pool)) if i not in front0]
    chosen = ranked + list(rng.choice(extra, size=3 - len(ranked), replace=False))
    return [pool[i] for i in chosen]


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator,
        pop_size: int = 30, max_evals: int = 3000, **kwargs) -> BaselineResult:
    dim = chromosome_length(workflow)
    evaluate_fn = make_evaluate_fn(workflow, environment)
    pop = init_population(dim, pop_size, rng)
    evals = evaluate_all(pop, evaluate_fn)

    archive = ExternalArchive()
    for ind in pop:
        archive.offer(Individual(ind.genes.copy(), ind.objectives))

    n_iters = max(1, (max_evals - evals) // max(pop_size, 1))
    it = 0
    while evals < max_evals:
        a = 2.0 * (1.0 - it / max(n_iters, 1))
        leaders = _pick_leaders(archive, pop, rng)
        for ind in pop:
            xs = []
            for leader in leaders:
                r1, r2 = rng.random(dim), rng.random(dim)
                A = 2 * a * r1 - a
                C = 2 * r2
                D = np.abs(C * leader.genes - ind.genes)
                xs.append(leader.genes - A * D)
            new_genes = np.clip(np.mean(xs, axis=0), 0.0, 0.999999)
            new_obj = evaluate_fn(new_genes)
            evals += 1
            ind.genes, ind.objectives = new_genes, new_obj
            archive.offer(Individual(new_genes.copy(), new_obj))
            if evals >= max_evals:
                break
        it += 1

    return BaselineResult("GWO", archive.members, evals)
