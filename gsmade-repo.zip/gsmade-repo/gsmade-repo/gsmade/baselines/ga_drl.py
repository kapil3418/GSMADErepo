"""GA-DRL (reference [10]). Table 2b: "DQN reward replaced by shared
vector; rollouts pooled into a front; GA-DRL's encoder retrained on
Table 2 families" -- the one structural difference from DRLMOTS is a
graph-attention encoder in front of the per-task state, reusing this
repo's own GraphAttentionLayer (the same building block gsmade/
gat_policy.py's GS-MADE seeding policy is built from), so the two
baselines differ exactly where the paper says they differ.

Simplification, documented honestly: the encoder's own weights are
initialized once per family and kept fixed through DQN training here
-- only the downstream Q-head is trained by gradient descent. Backing
the encoder's weights into the DQN's gradient (true end-to-end
training, the "retrained on Table 2 families" of Table 2b) is a
straightforward extension: thread the GAT layer's Tensor output through
dqn_common.run_episode instead of detaching it to a plain NumPy array
here, and include its params in dqn_common.train's `extra_params`.
"""
from __future__ import annotations

import numpy as np

from ..environment import Environment
from ..gat_policy import GraphAttentionLayer, build_adjacency, node_features
from ..nn import MLP, Tensor
from ..workflow import Workflow
from . import BaselineResult
from .dqn_common import TIERS, train

EMBED_DIM = 8
STATE_DIM = EMBED_DIM + 3  # GAT embedding + 3x per-tier normalized load


def _state_builder(workflow: Workflow, environment: Environment, rng: np.random.Generator):
    gat1 = GraphAttentionLayer(4, EMBED_DIM, rng)  # 4 structural features, no preference input here
    adjacency = build_adjacency(workflow)
    feats = node_features(workflow, preference=np.zeros(3))[:, :4]
    embeddings = gat1(Tensor(feats), adjacency).data  # (n, EMBED_DIM), fixed (see module docstring)

    task_ids = sorted(workflow.tasks.keys())
    embed_of = {t: embeddings[i] for i, t in enumerate(task_ids)}

    def build(tid: int, ctx: dict) -> np.ndarray:
        free_at = ctx["free_at"]
        tier_load = [np.mean([free_at[n.node_id] for n in environment.nodes_of_tier(tier)]) for tier in TIERS]
        span = max(max(tier_load) - min(tier_load), 1e-9)
        tier_load_n = [(t - min(tier_load)) / span for t in tier_load]
        return np.concatenate([embed_of[tid], tier_load_n])

    return build


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator,
        n_episodes: int = 150, lr: float = 1e-3, **kwargs) -> BaselineResult:
    qnet = MLP([STATE_DIM, 24, 3], rng)
    state_builder = _state_builder(workflow, environment, rng)
    archive = train(workflow, environment, qnet, state_builder, n_episodes, lr, rng)
    return BaselineResult("GA-DRL", archive.members, n_episodes * workflow.num_tasks)
