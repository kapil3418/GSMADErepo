"""The 11 baselines of Table 2b. Every baseline exposes a single
`run(workflow, environment, rng, **kwargs) -> BaselineResult` function so
scripts/run_evaluation.py can iterate over BASELINES uniformly.

  generic (applied directly under the shared LRV decoding + objective
  vector, Sec. 4.3): heft, minmin, pso, gwo, nsga2, cold_start_lshade.

  reimplemented from their source papers' own task models, adapted to
  the shared protocol (own Adaptation column in Table 2b): ipso_gwo,
  imoma, drlmots, ga_drl, pf_mppo.

HEFT and Min-Min are single-schedule heuristics with no population or
multi-objective front to speak of, so they report a one-point archive
-- this is exactly what the paper means by "the dash in Table 5".
"""
from dataclasses import dataclass

import numpy as np

from ..lshade import Individual


@dataclass
class BaselineResult:
    name: str
    individuals: list[Individual]
    evals_used: int

    @property
    def front(self) -> list[tuple]:
        return [ind.objectives for ind in self.individuals]


from . import cold_start_lshade  # noqa: E402
from . import ga_drl  # noqa: E402
from . import gwo  # noqa: E402
from . import heft  # noqa: E402
from . import imoma  # noqa: E402
from . import ipso_gwo  # noqa: E402
from . import minmin  # noqa: E402
from . import nsga2  # noqa: E402
from . import pf_mppo  # noqa: E402
from . import pso  # noqa: E402
from . import drlmots  # noqa: E402

BASELINES = {
    "HEFT": heft,
    "Min-Min": minmin,
    "PSO": pso,
    "GWO": gwo,
    "NSGA-II": nsga2,
    "cold-start L-SHADE": cold_start_lshade,
    "IPSO-GWO": ipso_gwo,
    "IMOMA": imoma,
    "DRLMOTS": drlmots,
    "GA-DRL": ga_drl,
    "PF-MPPO": pf_mppo,
}
