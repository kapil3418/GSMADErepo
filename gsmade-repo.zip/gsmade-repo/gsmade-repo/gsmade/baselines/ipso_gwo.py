"""IPSO-GWO (reference [1]). Table 2b's adaptation: "weighted sum
replaced by shared objective vector; hand-off as in [1]" -- i.e. keep
the two-phase structure (an improved PSO explores for the first half of
the budget, then hands off to a GWO phase for the second half) but drive
both phases with the same Pareto-dominance/archive machinery every other
multi-objective baseline here uses, instead of the source paper's
single weighted-sum fitness.

"Improved" PSO = linearly decaying inertia weight (0.9 -> 0.4), the
specific improvement [1] itself makes over plain PSO. The hand-off
is literal: phase 2's initial swarm is phase 1's final swarm, and
phase 1's best-crowding-distance archive member seeds phase 2's alpha
wolf for its first iteration.
"""
from __future__ import annotations

import numpy as np

from ..encoding import chromosome_length
from ..environment import Environment
from ..lshade import ExternalArchive, Individual, crowding_distance, dominates, non_dominated_sort
from ..workflow import Workflow
from . import BaselineResult
from .moea_common import evaluate_all, init_population, make_evaluate_fn

C1, C2 = 1.5, 1.5


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator,
        pop_size: int = 30, max_evals: int = 3000, **kwargs) -> BaselineResult:
    dim = chromosome_length(workflow)
    evaluate_fn = make_evaluate_fn(workflow, environment)
    half = max_evals // 2

    # ---- phase 1: improved PSO (decaying inertia) -------------------------
    pop = init_population(dim, pop_size, rng)
    evals = evaluate_all(pop, evaluate_fn)
    velocity = [np.zeros(dim) for _ in pop]
    pbest = [Individual(ind.genes.copy(), ind.objectives) for ind in pop]
    archive = ExternalArchive()
    for ind in pop:
        archive.offer(Individual(ind.genes.copy(), ind.objectives))

    phase1_iters = max(1, (half - evals) // max(pop_size, 1))
    it = 0
    while evals < half:
        w = 0.9 - 0.5 * min(it / max(phase1_iters, 1), 1.0)
        for i, ind in enumerate(pop):
            leaders = archive.members if archive.members else pop
            leader = leaders[int(rng.integers(0, len(leaders)))]
            r1, r2 = rng.random(dim), rng.random(dim)
            velocity[i] = (w * velocity[i] + C1 * r1 * (pbest[i].genes - ind.genes)
                           + C2 * r2 * (leader.genes - ind.genes))
            ind.genes = np.clip(ind.genes + velocity[i], 0.0, 0.999999)
            ind.objectives = evaluate_fn(ind.genes)
            evals += 1
            archive.offer(Individual(ind.genes.copy(), ind.objectives))
            if dominates(ind.objectives, pbest[i].objectives):
                pbest[i] = Individual(ind.genes.copy(), ind.objectives)
            elif not dominates(pbest[i].objectives, ind.objectives) and rng.random() < 0.5:
                pbest[i] = Individual(ind.genes.copy(), ind.objectives)
            if evals >= half:
                break
        it += 1

    # hand-off: best (most central, highest-crowding) phase-1 archive member
    if archive.members:
        fronts = non_dominated_sort(archive.members)
        dist = crowding_distance(archive.members, fronts[0])
        alpha_fixed = archive.members[max(fronts[0], key=lambda i: dist[i])]
    else:
        alpha_fixed = pop[0]

    # ---- phase 2: GWO seeded from phase 1's swarm --------------------------
    n_iters = max(1, (max_evals - evals) // max(pop_size, 1))
    it = 0
    while evals < max_evals:
        a = 2.0 * (1.0 - it / max(n_iters, 1))
        if it == 0:
            leaders = [alpha_fixed, alpha_fixed, alpha_fixed]
            if len(archive.members) >= 3:
                fronts = non_dominated_sort(archive.members)
                dist = crowding_distance(archive.members, fronts[0])
                ranked = sorted(fronts[0], key=lambda i: -dist[i])[:3]
                leaders = [archive.members[i] for i in ranked]
        else:
            pool = archive.members if len(archive.members) >= 3 else pop
            fronts = non_dominated_sort(pool)
            dist = crowding_distance(pool, fronts[0])
            ranked = sorted(fronts[0], key=lambda i: -dist[i])
            leaders = [pool[i] for i in (ranked[:3] if len(ranked) >= 3 else (ranked * 3)[:3])]

        for ind in pop:
            xs = []
            for leader in leaders:
                r1, r2 = rng.random(dim), rng.random(dim)
                A = 2 * a * r1 - a
                C = 2 * r2
                D = np.abs(C * leader.genes - ind.genes)
                xs.append(leader.genes - A * D)
            new_genes = np.clip(np.mean(xs, axis=0), 0.0, 0.999999)
            new_obj = evaluate_fn(new_genes)
            evals += 1
            ind.genes, ind.objectives = new_genes, new_obj
            archive.offer(Individual(new_genes.copy(), new_obj))
            if evals >= max_evals:
                break
        it += 1

    return BaselineResult("IPSO-GWO", archive.members, evals)
