"""GS-MADE: Graph-Seeded Memetic Adaptive Differential Evolution.

Reference implementation accompanying:
  Kumar, K. and Singh, M., "GS-MADE: A Graph-Seeded Memetic Metaheuristic
  for Generalizable Multi-Objective Workflow Scheduling in Fog-Cloud
  Systems", International Journal of Intelligent Engineering and Systems.

See README.md for setup and reproduction instructions.
"""

__version__ = "0.1.0"
