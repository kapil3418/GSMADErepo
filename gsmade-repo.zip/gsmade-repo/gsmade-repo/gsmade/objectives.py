"""Three-objective evaluation: makespan (f1), energy (f2), cost (f3).

simulate() is the discrete-event core shared by every scheduler in this
repo (GS-MADE and all 11 baselines) -- it is the "simulator harness" the
paper's Data and code availability section refers to. It is intentionally
a simplified, deterministic re-implementation of a FogWorkflowSim-style
three-tier simulator: each task's start time is the later of (a) its
assigned node becoming free and (b) all of its predecessors' outputs
having arrived (0 transfer time if predecessor ran on the same node).

Energy (Eq. (2) of the paper) is computation energy (active power while a
node executes a task, idle power otherwise, integrated over the makespan)
plus a communication term Ecomm = sum over inter-node edges of
(data volume / effective bandwidth) * a fixed radio power draw -- this is
the term EDIT 10 in the paper ties to Fig. 3's transfer-count reduction.
Cost is usage time * the node's tier price (Table 3); the IoT/edge tier
is priced at $0/s so only fog and cloud usage contribute.
"""
from __future__ import annotations

from dataclasses import dataclass

from .environment import Environment
from .workflow import Workflow

RADIO_POWER_W = 0.4  # nominal radio draw while transferring, both endpoints


@dataclass
class ScheduleResult:
    makespan_s: float
    energy_j: float
    cost_usd: float
    deadline_s: float
    deadline_met: bool
    num_inter_tier_transfers: int
    cloud_task_fraction: float
    fog_critical_path_fraction: float
    start: dict
    finish: dict
    node_of: dict

    @property
    def objective_vector(self) -> tuple[float, float, float]:
        return (self.makespan_s, self.energy_j, self.cost_usd)


def estimate_deadline(workflow: Workflow, environment: Environment) -> float:
    """A HEFT-style lower-bound makespan (fastest node per task, no
    contention) scaled by the workflow's deadline_factor (kappa), used as
    D = kappa * C_max^HEFT per the paper's deadline-satisfaction metric."""
    fastest_mips = max(n.mips for n in environment.nodes)
    # crude critical-path estimate: sum of each task's fastest-case runtime
    # along the longest path, ignoring contention/transfer (a lower bound)
    import networkx as nx
    longest = nx.dag_longest_path(workflow.graph, weight=None)
    cp_time = sum(workflow.tasks[t].workload_mi / fastest_mips * 1000.0 for t in longest)
    return workflow.deadline_factor * max(cp_time, 1e-6)


def simulate(workflow: Workflow, environment: Environment,
             order: list[int], assignment: dict[int, int]) -> ScheduleResult:
    nodes = environment.nodes
    node_free_at = {n.node_id: 0.0 for n in nodes}
    start: dict[int, float] = {}
    finish: dict[int, float] = {}
    busy_time = {n.node_id: 0.0 for n in nodes}
    transfer_energy = 0.0
    inter_tier_transfers = 0
    cloud_tasks = 0

    for tid in order:
        node_id = assignment[tid]
        node = nodes[node_id]
        ready_time = 0.0
        for pred in workflow.predecessors(tid):
            pred_node = nodes[assignment[pred]]
            arrival = finish[pred]
            if pred_node.node_id != node.node_id:
                data_mb = workflow.edge_data_mb(pred, tid)
                bw = environment.effective_bandwidth_mbps(pred_node, node)
                transfer_s = (data_mb * 8.0) / bw  # Mb / Mbps = s
                arrival += transfer_s
                transfer_energy += RADIO_POWER_W * transfer_s
                inter_tier_transfers += 1
            ready_time = max(ready_time, arrival)
        st = max(ready_time, node_free_at[node.node_id])
        exec_s = workflow.tasks[tid].workload_mi / node.mips * 1000.0
        ft = st + exec_s
        start[tid] = st
        finish[tid] = ft
        node_free_at[node.node_id] = ft
        busy_time[node.node_id] += exec_s
        if node.tier == "cloud":
            cloud_tasks += 1

    makespan = max(finish.values()) if finish else 0.0

    compute_energy = 0.0
    cost = 0.0
    for node in nodes:
        busy = busy_time[node.node_id]
        idle = max(makespan - busy, 0.0)
        compute_energy += node.power_active_w * busy + node.power_idle_w * idle
        cost += busy * node.price_per_s

    energy = compute_energy + transfer_energy
    deadline = estimate_deadline(workflow, environment)

    cp_tasks = _critical_path_tasks(workflow)
    fog_cp = sum(1 for t in cp_tasks if nodes[assignment[t]].tier == "fog") / max(len(cp_tasks), 1)

    return ScheduleResult(
        makespan_s=makespan,
        energy_j=energy,
        cost_usd=cost,
        deadline_s=deadline,
        deadline_met=makespan <= deadline,
        num_inter_tier_transfers=inter_tier_transfers,
        cloud_task_fraction=cloud_tasks / max(workflow.num_tasks, 1),
        fog_critical_path_fraction=fog_cp,
        start=start, finish=finish, node_of={t: assignment[t] for t in order},
    )


def _critical_path_tasks(workflow: Workflow) -> list[int]:
    import networkx as nx
    return nx.dag_longest_path(workflow.graph, weight=None)
