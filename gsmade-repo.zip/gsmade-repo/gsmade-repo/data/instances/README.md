# Instances

Empty until you run the generators -- instance files are reproducible
artifacts, not checked into the repo (see `.gitignore`).

## Synthetic families (Montage, CyberShake, Epigenomics, LIGO_Inspiral, SIPHT)

```bash
python scripts/generate_instances.py --seeds-per-scale 6
```

Writes `data/instances/<Family>/<Family>_<scale>_seed<N>.json` for every
(family, scale) pair at 100/500/1000 tasks, plus `data/instances/manifest.json`
listing every file with its generator seed and Table-2-style structural
stats (|E|, CCR, depth, max width). See `scripts/generators.py`'s module
docstring for exactly what these generators are (and are not -- they are
a documented structural approximation of each family's known topology,
not the real Pegasus synthetic generator).

## Real traces (1000Genome, Cycles, SoyKB, SRA_Search)

Not included -- these are WfCommons' own recorded executions (reference
[24] in the paper), released under their own permanent identifier.
Fetch them yourself, e.g.:

```bash
pip install wfcommons
# or download a trace .json directly, e.g. from
# https://github.com/wfcommons/pegasus-instances
```

then convert into this repo's format:

```bash
python scripts/convert_wfcommons_trace.py \
    --in /path/to/trace.json --family 1000Genome \
    --out data/instances/1000Genome/
```

`scripts/convert_wfcommons_trace.py`'s module docstring documents the
expected WfCommons JSON schema and how edges are inferred when a trace
gives file-level input/output lists instead of explicit parent/child ids.
