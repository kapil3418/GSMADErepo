"""Finite-difference gradient checks for gsmade/nn.py's autodiff engine --
every Tensor op used anywhere else in this repo (the GAT policy, the DQN
and PPO baselines) is checked here against numerical differentiation, the
same way these were verified ad hoc while building the repo, just made
permanent and repeatable."""
from __future__ import annotations

import numpy as np
import pytest

from gsmade.nn import Adam, Linear, MLP, Tensor

RNG = np.random.default_rng(0)


def _numerical_grad(f, x: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    grad = np.zeros_like(x)
    it = np.nditer(x, flags=["multi_index"])
    for _ in it:
        idx = it.multi_index
        orig = x[idx]
        x[idx] = orig + eps
        f_plus = f(x)
        x[idx] = orig - eps
        f_minus = f(x)
        x[idx] = orig
        grad[idx] = (f_plus - f_minus) / (2 * eps)
    return grad


def _check(op, shape=(3, 2), seed=0):
    """Build a scalar loss = op(Tensor(x)).sum() (or op already returns a
    scalar Tensor), compare Tensor.backward()'s gradient on x against a
    central finite-difference estimate."""
    rng = np.random.default_rng(seed)
    x0 = rng.uniform(0.2, 1.5, size=shape)  # stay away from 0 for pow/log/div

    def forward(xv):
        t = Tensor(xv.copy(), requires_grad=True)
        out = op(t)
        if out.data.shape != ():
            out = out.sum()
        return t, out

    t, out = forward(x0)
    out.backward()
    analytic = t.grad.copy()

    def scalar_f(xv):
        _, o = forward(xv)
        return float(o.data)

    numeric = _numerical_grad(scalar_f, x0.copy())
    assert np.allclose(analytic, numeric, atol=1e-4, rtol=1e-3), f"{op} grad mismatch"


@pytest.mark.parametrize("op", [
    lambda t: t + 3.0,
    lambda t: 3.0 + t,
    lambda t: t - 1.5,
    lambda t: 1.5 - t,
    lambda t: -t,
    lambda t: t * 2.0,
    lambda t: t / 2.0,
    lambda t: t.pow(2.0),
    lambda t: t.pow(0.5),
    lambda t: t.pow(-1.0),
    lambda t: t ** 3.0,
    lambda t: t.relu(),
    lambda t: t.leaky_relu(0.1),
    lambda t: t.tanh(),
    lambda t: t.sigmoid(),
    lambda t: t.exp(),
    lambda t: t.log(),
    lambda t: t.sum(axis=0),
    lambda t: t.mean(),
    lambda t: t.reshape((6,)),
    # NOTE: softmax(t).sum(axis=1) is identically 1 for every row (a weak,
    # gradient-insensitive check), so weight it by t itself to get a
    # genuinely input-dependent scalar that exercises softmax's backward
    # Jacobian-vector product.
    lambda t: (t.softmax(axis=1) * t).sum(),
    lambda t: (t * t).sum(),
])
def test_unary_ops_match_finite_difference(op):
    _check(op)


def test_matmul_gradient():
    rng = np.random.default_rng(1)
    a0 = rng.uniform(0.2, 1.0, size=(3, 4))
    b = Tensor(rng.uniform(0.2, 1.0, size=(4, 2)), requires_grad=False)

    def forward(av):
        a = Tensor(av.copy(), requires_grad=True)
        out = (a @ b).sum()
        return a, out

    a, out = forward(a0)
    out.backward()
    analytic = a.grad.copy()

    def scalar_f(av):
        _, o = forward(av)
        return float(o.data)

    numeric = _numerical_grad(scalar_f, a0.copy())
    assert np.allclose(analytic, numeric, atol=1e-4, rtol=1e-3)


def test_broadcasting_add_unbroadcasts_correctly():
    rng = np.random.default_rng(2)
    a = Tensor(rng.uniform(size=(4, 3)), requires_grad=True)
    b = Tensor(rng.uniform(size=(1, 3)), requires_grad=True)
    out = (a + b).sum()
    out.backward()
    assert a.grad.shape == (4, 3)
    assert b.grad.shape == (1, 3)
    assert np.allclose(b.grad, 4.0)  # b broadcast over 4 rows, d(sum)/db = 4 for each column


def test_concat_gradient_routes_to_right_slice():
    a = Tensor(np.ones((2, 3)), requires_grad=True)
    b = Tensor(np.ones((2, 2)), requires_grad=True)
    out = Tensor.concat([a, b], axis=1)
    (out * out).sum().backward()
    assert np.allclose(a.grad, 2.0)
    assert np.allclose(b.grad, 2.0)


def test_getitem_gradient_scatters_correctly():
    x = Tensor(np.arange(6, dtype=float), requires_grad=True)
    idx = [0, 0, 2]  # repeated index must accumulate via np.add.at
    out = x[idx].sum()
    out.backward()
    expected = np.zeros(6)
    expected[0] = 2.0
    expected[2] = 1.0
    assert np.allclose(x.grad, expected)


def test_linear_and_mlp_shapes_and_trainability():
    rng = np.random.default_rng(3)
    mlp = MLP([4, 8, 1], rng)
    x = Tensor(rng.uniform(size=(5, 4)))
    out = mlp(x)
    assert out.shape == (5, 1)

    opt = Adam(mlp.params(), lr=0.05)
    target = Tensor(np.ones((5, 1)))
    losses = []
    for _ in range(50):
        opt.zero_grad()
        pred = mlp(x)
        loss = ((pred - target) * (pred - target)).mean()
        loss.backward()
        opt.step()
        losses.append(float(loss.data))
    # Adam should drive a trivial MSE-to-constant-target loss down substantially
    assert losses[-1] < losses[0] * 0.5


def test_linear_layer_gradient_matches_finite_difference():
    rng = np.random.default_rng(4)
    layer = Linear(3, 2, rng)
    x0 = rng.uniform(size=(2, 3))

    def forward(xv):
        x = Tensor(xv.copy(), requires_grad=True)
        out = layer(x).sum()
        return x, out

    x, out = forward(x0)
    out.backward()
    analytic = x.grad.copy()

    def scalar_f(xv):
        _, o = forward(xv)
        return float(o.data)

    numeric = _numerical_grad(scalar_f, x0.copy())
    assert np.allclose(analytic, numeric, atol=1e-4, rtol=1e-3)
