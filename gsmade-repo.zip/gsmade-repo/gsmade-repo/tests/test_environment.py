"""configs/three_tier.yaml loads into exactly Table 3's shape: node
counts, pricing (iot_edge is free, fog/cloud are priced), and ranges."""
from __future__ import annotations


def test_tier_node_counts(environment):
    assert len(environment.nodes_of_tier("iot_edge")) == 8
    assert len(environment.nodes_of_tier("fog")) == 12
    assert len(environment.nodes_of_tier("cloud")) == 6
    assert environment.num_nodes == 26


def test_iot_edge_tier_is_unpriced(environment):
    assert all(n.price_per_s == 0.0 for n in environment.nodes_of_tier("iot_edge"))


def test_fog_and_cloud_pricing_matches_config(environment):
    assert all(n.price_per_s == 1.2e-4 for n in environment.nodes_of_tier("fog"))
    assert all(n.price_per_s == 9.6e-4 for n in environment.nodes_of_tier("cloud"))


def test_mips_ranges_match_table_3(environment):
    assert all(n.mips == 500.0 for n in environment.nodes_of_tier("iot_edge"))
    assert all(1500.0 <= n.mips <= 3000.0 for n in environment.nodes_of_tier("fog"))
    assert all(8000.0 <= n.mips <= 12000.0 for n in environment.nodes_of_tier("cloud"))
    # a fixed range (iot_edge) collapses to one value; a sampled range (fog,
    # cloud) should actually vary across the 12/6 sampled nodes, not just
    # happen to sit at the range's edges
    fog_mips = {n.mips for n in environment.nodes_of_tier("fog")}
    assert len(fog_mips) > 1


def test_environment_is_reproducible_from_the_same_seed(environment):
    import os
    from gsmade.environment import Environment
    path = os.path.join(os.path.dirname(__file__), "..", "configs", "three_tier.yaml")
    other = Environment.from_config(path)
    assert [n.mips for n in environment.nodes] == [n.mips for n in other.nodes]
    assert [n.power_active_w for n in environment.nodes] == [n.power_active_w for n in other.nodes]


def test_effective_bandwidth_is_the_tighter_of_the_two_links(environment):
    fog = environment.nodes_of_tier("fog")[0]
    cloud = environment.nodes_of_tier("cloud")[0]
    assert environment.effective_bandwidth_mbps(fog, cloud) == min(fog.link_mbps, cloud.link_mbps)


def test_to_rows_matches_table_3_layout(environment):
    rows = environment.to_rows()
    tiers = [r["Tier"] for r in rows]
    assert tiers == ["iot_edge", "fog", "cloud"]
    for r in rows:
        assert r["Nodes"] in (8, 12, 6)
