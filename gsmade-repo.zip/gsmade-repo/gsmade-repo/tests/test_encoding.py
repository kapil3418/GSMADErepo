"""LRV encoding/decoding: the precedence-feasibility-by-construction
guarantee and the exact decode -> reencode -> decode round trip that
gsmade/vns.py's neighbourhood moves depend on."""
from __future__ import annotations

import numpy as np
import pytest

from gsmade import encoding
from gsmade.vns import reencode


def test_chromosome_length_is_twice_task_count(toy_workflow):
    assert encoding.chromosome_length(toy_workflow) == 2 * toy_workflow.num_tasks


@pytest.mark.parametrize("seed", range(10))
def test_decode_order_is_always_precedence_feasible(toy_workflow, seed):
    rng = np.random.default_rng(seed)
    genes = encoding.random_genes(toy_workflow, rng)
    order = encoding.decode_order(toy_workflow, genes[: toy_workflow.num_tasks])

    assert sorted(order) == sorted(toy_workflow.tasks.keys())  # a permutation of all tasks
    position = {tid: i for i, tid in enumerate(order)}
    for u, v in toy_workflow.graph.edges:
        assert position[u] < position[v], f"predecessor {u} scheduled after successor {v}"


@pytest.mark.parametrize("seed", range(5))
def test_decode_assignment_is_always_in_range(toy_workflow, seed):
    rng = np.random.default_rng(seed)
    num_nodes = 17
    genes = encoding.random_genes(toy_workflow, rng)
    assignment = encoding.decode_assignment(toy_workflow, genes[toy_workflow.num_tasks:], num_nodes)
    assert set(assignment.keys()) == set(toy_workflow.tasks.keys())
    assert all(0 <= node_id < num_nodes for node_id in assignment.values())


def test_decode_assignment_clips_out_of_range_genes(toy_workflow):
    # resource genes are normally in [0,1), but decode_assignment must not
    # crash or go out of bounds if handed something outside that range
    # (e.g. a GAT policy output that drifted slightly past 1.0).
    n = toy_workflow.num_tasks
    genes = np.array([1.5] * n)  # all > 1
    assignment = encoding.decode_assignment(toy_workflow, genes, num_nodes=5)
    assert all(node_id == 4 for node_id in assignment.values())  # clipped to last node
    genes_neg = np.array([-0.5] * n)
    assignment_neg = encoding.decode_assignment(toy_workflow, genes_neg, num_nodes=5)
    assert all(node_id == 0 for node_id in assignment_neg.values())


@pytest.mark.parametrize("seed", range(10))
def test_reencode_decode_round_trip_is_exact(toy_workflow, seed):
    """The critical guarantee gsmade/vns.py's module docstring calls out:
    decode(reencode(order, assignment)) must reproduce the exact same
    (order, assignment), so VNS-improved individuals re-enter the shared
    chromosome population without losing the move that improved them."""
    rng = np.random.default_rng(seed)
    num_nodes = 11
    genes = encoding.random_genes(toy_workflow, rng)
    order, assignment = encoding.decode(toy_workflow, genes, num_nodes)

    re_genes = reencode(toy_workflow, order, assignment, num_nodes)
    order2, assignment2 = encoding.decode(toy_workflow, re_genes, num_nodes)

    assert order2 == order
    assert assignment2 == assignment


def test_genes_from_priority_vector_packs_in_the_expected_layout():
    priority = np.array([0.1, 0.2, 0.3])
    resource = np.array([0.4, 0.5, 0.6])
    genes = encoding.genes_from_priority_vector(priority, resource)
    assert np.allclose(genes, [0.1, 0.2, 0.3, 0.4, 0.5, 0.6])
